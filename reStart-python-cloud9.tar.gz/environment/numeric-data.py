print("Python has three numeric types: int, float and complex")
myValue=1
print(myValue)
print(type(myValue))
print(str(myValue) + " is of the data type " + str(type(myValue)))
pi=3.14
age=21.0
print(pi)
print(str(pi) + str(age))
print(age + pi)
thing=5j
print(thing)
print(type(thing))
print(str(thing) + " is of the data type " + str(type(thing)))
myString= "This is a string."
print(myString)
print(type(myString))
print(myString + " is of the data type " + str(type(myString)))
firstString = "water"
secondString = "fall"
thirdString = firstString + secondString
print(thirdString)
name = input("What is your name? Christian")
print(name)
color = input("What is your favorite color? Purple")
animal = input("What is your favorite animal? Dog")
print("{}, you like a {} {}!".format(name,color,animal))
myFruitList = ["apple", "banana", "cherry"]
print(myFruitList)
print(type(myFruitList))
myFruitList = ["apple", "banana", "cherry"]
print(myFruitList)
print(type(myFruitList))
print(myFruitList[0])
print(myFruitList[1])
print(myFruitList[2])
myFruitList[2] = "orange"
print(myFruitList)
